VELORA CLOTHING BRAND WEBSITE

CONTENTS
- index.html: complete responsive one-page clothing brand website.

HOW TO USE WITH TIINY.HOST
1. Open the ZIP file and extract index.html.
2. Go to Tiiny.host and sign in or create an account.
3. Upload index.html (or upload the ZIP if the upload screen supports ZIP websites).
4. Follow Tiiny.host's prompts to publish your site.
5. Open the published link on your phone to check it.

IMPORTANT CUSTOMIZATION NOTES
- VELORA is a sample brand name. Search for VELORA in index.html and replace it with your brand name.
- Product names, prices, copy, email address, and images are examples; customize them before launch.
- Product photos load from Unsplash, so an internet connection is needed to show them.
- The Add to bag buttons are a front-end demo only. They do not process orders or payments.
- The newsletter form is a demo and does not store email addresses.
- Replace hello@velora.example with your real contact email.
